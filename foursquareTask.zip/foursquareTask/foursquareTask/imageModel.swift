//
//  imageModel.swift
//  foursquareTask
//
//  Created by apple on 10/30/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation
class imageModal: NSObject{
    var prefix: String
    var suffix: String
    init(prefix: String,suffix: String) {
        self.prefix = prefix
        self.suffix = suffix
    }
}
