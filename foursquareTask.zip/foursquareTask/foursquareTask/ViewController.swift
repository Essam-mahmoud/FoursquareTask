//
//  ViewController.swift
//  foursquareTask
//
//  Created by apple on 10/30/19.
//  Copyright © 2019 apple. All rights reserved.
//

import UIKit 
import Pilgrim
import MapKit
import SwiftyJSON
import Kingfisher

class ViewController: UIViewController {
    
    //outlet
    
    @IBOutlet weak var placesTableView: UITableView!
    @IBOutlet weak var segmentSelector: UISegmentedControl!
    var http = HttpHelper()  // instasiate object to network layer
    var placesArray = [placeModel]()
    var placesImages = [imageModal]()
    var lang = 0
    var lat = 0
    var isRealTime = true
    
    var locationManager:CLLocationManager!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        segmentSelector.addTarget(self, action: #selector(changeKind), for: .valueChanged)
        locationManager = CLLocationManager()
        locationManager.delegate = self
        http.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = 500     // to update location every 500 meters
        locationManager.allowsBackgroundLocationUpdates = true
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
        setSegment()
        
        // Do any additional setup after loading the view.
        
        Appcommon.ShowLoader(self.view, color: UIColor(red: 0, green: 0, blue: 0, alpha: 0.35))
        http.Postwithoutheader(url: APIConstants.getVenueDate, parameters: [:], Tag: 1)
        
    
    }
    func setSegment(){
        let segmentResult = UserDefaults.standard.object(forKey: "kind") as? String
        if segmentResult == "RealTime" || segmentResult == ""{
            segmentSelector.selectedSegmentIndex = 0
        }else{
             segmentSelector.selectedSegmentIndex = 1
        }
    }
    
    @objc func changeKind(){
        switch segmentSelector.selectedSegmentIndex {
        case 0:
            showAlert(message: "Do you want to change to Real Time mode?", kind: "RealTime", isreal: true)
        case 1:
            showAlert(message: "Do you want to change to Static mode?", kind: "SingleUpdate", isreal: false)
        default:
            break
            
        }
    }
    
    //MARK:- Show Alert function
    
    func showAlert(message: String, kind: String, isreal: Bool){
        let alert = UIAlertController(title: "Warinig", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (result) in
            UserDefaults.standard.set(kind, forKey: "kind")
            self.isRealTime = true
            Appcommon.ShowLoader(self.view, color: UIColor(red: 0, green: 0, blue: 0, alpha: 0.35))
            self.http.Postwithoutheader(url: APIConstants.getVenueDate, parameters: [:], Tag: 1)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }


}

//MARK:- tableView Delegates and Data source

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return placesArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = placesTableView.dequeueReusableCell(withIdentifier: "placeInfoCell", for: indexPath) as! placeInfoCell
        cell.setup(placeObj: placesArray[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        placesTableView.deselectRow(at: indexPath, animated: true)
    }
}

//MARK:- Locaton Helper Delegate To get lat & lang
extension ViewController: CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locationArray = locations as NSArray
        let locationObj = locationArray.lastObject as! CLLocation
        let coord = locationObj.coordinate
        let lang = coord.longitude
        let lat = coord.latitude
        APIConstants.lang = "\(lang)"
        APIConstants.lat = "\(lat)"
        if isRealTime{   // call the endPoint every 500 meters if the real time mode is on
            Appcommon.ShowLoader(self.view, color: UIColor(red: 0, green: 0, blue: 0, alpha: 0.35))
            http.GetWithoutHeader(url: APIConstants.getVenuePhotos, parameters: [:], Tag: 1)
        }
    }
}

//MARK:- Http Helper Delegate To get data

extension ViewController: HttpHelperDelegate{
    func receivedResponse(dictResponse: Any, Tag: Int) {

        print(dictResponse)

        let json = JSON(dictResponse)
        if Tag == 1{
            Appcommon.dismissLoader(self.view)
            let response = json["response"]
            let data = response["venues"].arrayValue
            for venue in data{
                
                //Parsing Data
                
                let id = venue["id"].stringValue
                let location = venue["location"]
                let country = location["country"].stringValue
                let address = location["address"].stringValue
                let city = location["city"].stringValue
                let state = location["state"].stringValue
                let distance = location["distance"].intValue
                let placeObject = placeModel(Id: id, name: venue["name"].stringValue, address: address + " , " + city + " , " + state + " , " + country , distance: distance)
                placesArray.append(placeObject)

            }
            placesTableView.reloadData()
        }
    }
    func receivedErrorWithStatusCode(statusCode: Int) {
        //Loader.showError(message: "Error: Please Check internet connection")
    }
    
    func retryResponse(numberOfrequest: Int) {
        
    }
    
    
}

