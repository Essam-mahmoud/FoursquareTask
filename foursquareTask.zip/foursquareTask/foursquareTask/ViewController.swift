//
//  ViewController.swift
//  foursquareTask
//
//  Created by apple on 10/30/19.
//  Copyright © 2019 apple. All rights reserved.
//

import UIKit
import Pilgrim
import MapKit
import SwiftyJSON
import Kingfisher

class ViewController: UIViewController {
    
    //outlet intialize
    @IBOutlet weak var placesTableView: UITableView!
    @IBOutlet weak var segmentSelector: UISegmentedControl!
    var http = HttpHelper()  // instasiate object to network layer
    var placesArray = [placeModel]()
    var placesImages = [imageModal]()
    var lang = 0
    var lat = 0
    
    var locationManager:CLLocationManager!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UserDefaults.standard.set("RealTime", forKey: "kind")
        segmentSelector.addTarget(self, action: #selector(changeKind), for: .valueChanged)
        locationManager = CLLocationManager()
        locationManager.delegate = self
        http.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
        // Do any additional setup after loading the view.
        Appcommon.ShowLoader(self.view, color: UIColor(red: 0, green: 0, blue: 0, alpha: 0.35))
        http.Postwithoutheader(url: APIConstants.getVenueDate, parameters: [:], Tag: 1)
      //  http.Postwithoutheader(url: APIConstants.getVenuePhotos, parameters: ["CLIENT ID":"5RZXGM0D2KZFI30ZCPC5PR0F4GGH0C0N0FAHW3KBZCRLZZ1E","CLIENT SECRET":"INF4LY1PL5VRO2MYAL1RWQT4HQHYQHHREXRAXSJWTQNRBTI0"], Tag: 2)
    }
    
    @objc func changeKind(){
        switch segmentSelector.selectedSegmentIndex {
        case 0:
            UserDefaults.standard.set("RealTime", forKey: "kind")
        case 1:
            UserDefaults.standard.set("SingleUpdate", forKey: "kind")
        default:
            break
        }
    }


}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return placesArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = placesTableView.dequeueReusableCell(withIdentifier: "placeInfoCell", for: indexPath) as! placeInfoCell
        cell.nameLBL.text = placesArray[indexPath.row].name
        cell.addressLBL.text = placesArray[indexPath.row].address
        let StringURL = placesImages[indexPath.row].prefix + "/200x200/" + placesImages[indexPath.row].suffix
        let url = URL(string: StringURL)
        cell.placeImageView.kf.setImage(with: url)
        return cell
    } 
}


extension ViewController: CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        var locationArray = locations as NSArray
        var locationObj = locationArray.lastObject as! CLLocation
        var coord = locationObj.coordinate
        print(coord.latitude)
        print(coord.longitude)
    }
}

extension ViewController: HttpHelperDelegate{
    func receivedResponse(dictResponse: Any, Tag: Int) {
        print(dictResponse)
        let json = JSON(dictResponse)
        if Tag == 1{
            Appcommon.dismissLoader(self.view)
            let response = json["response"]
            let data = response["venues"].arrayValue
            for venue in data{
                let location = venue["location"]
                let country = location["country"].stringValue
                let city = location["city"].stringValue
                let state = location["state"].stringValue
                let placeObject = placeModel(name: venue["name"].stringValue, address: country+" , "+state+" , "+city)
                placesArray.append(placeObject)
                let cat = venue["categories"].arrayValue
                for image in cat{
                    let icon = image["icon"]
                    let imageobj = imageModal(prefix: icon["prefix"].stringValue, suffix: icon["suffix"].stringValue)
                    placesImages.append(imageobj)
                }
            }
            placesTableView.reloadData()
        }
        /*if Tag == 2{
            let response = json["response"]
            let Photo = response["photos"]
            let images = Photo["items"].arrayValue
            for image in images{
                let imageobject = imageModal(prefix: image["prefix"].stringValue, suffix: image["suffix"].stringValue, width: image["width"].stringValue, height: image["height"].stringValue)
                placesImages.append(imageobject)
            }
            placesTableView.reloadData()
        }*/
    }
    
    func receivedErrorWithStatusCode(statusCode: Int) {
        
    }
    
    func retryResponse(numberOfrequest: Int) {
        
    }
    
    
}

