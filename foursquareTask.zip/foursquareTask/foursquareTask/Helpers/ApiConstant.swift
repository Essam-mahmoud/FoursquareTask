//
//  ApiConstant.swift
//  foursquareTask
//
//  Created by apple on 10/30/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation

open class APIConstants {
    static var ID = ""
    static var lang = "30.0565124,"
    static var lat = "31.3400703"
    static let secuirtyId = "&client_secret=INF4LY1PL5VRO2MYAL1RWQT4HQHYQHHREXRAXSJWTQNRBTI0&v=20191030"
    static let clientId = "5RZXGM0D2KZFI30ZCPC5PR0F4GGH0C0N0FAHW3KBZCRLZZ1E"
    static var base = "https://api.foursquare.com/v2/venues/search?ll="+lang+lat+"&client_id="
    static let getVenueDate = base + clientId + secuirtyId
    
    static var basePhoto = "https://api.foursquare.com/v2/venues/" + ID + "/photos?client_id="
    static let getVenuePhotos = basePhoto + clientId + secuirtyId
}

