//
//  ApiConstant.swift
//  foursquareTask
//
//  Created by apple on 10/30/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation

open class APIConstants {
    static let lang = "40.7,"
    static let lat = "-7"
    static let secuirtyId = "&client_secret=INF4LY1PL5VRO2MYAL1RWQT4HQHYQHHREXRAXSJWTQNRBTI0&v=20191030"
    static let clientId = "5RZXGM0D2KZFI30ZCPC5PR0F4GGH0C0N0FAHW3KBZCRLZZ1E"
    static let base = "https://api.foursquare.com/v2/venues/search?ll="+lang+lat+"&client_id="
    static let getVenueDate = base + clientId + secuirtyId
    static let getVenuePhotos = "https://api.foursquare.com/v2/venues/4dc0bfe352b1877d85a50201/photos?client_id=5RZXGM0D2KZFI30ZCPC5PR0F4GGH0C0N0FAHW3KBZCRLZZ1E&client_secret=INF4LY1PL5VRO2MYAL1RWQT4HQHYQHHREXRAXSJWTQNRBTI0&v=20191030"
}

