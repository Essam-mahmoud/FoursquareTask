//
//  HttpController.swift
//  AshakAlena
//
//  Created by Mohammad Farhan on 22/12/177/25/17.
//  Copyright © 2017 Mohammad Farhan. All rights reserved.
//

import Foundation
import Alamofire
protocol HttpHelperDelegate {
    func receivedResponse(dictResponse:Any,Tag:Int)
    func receivedErrorWithStatusCode(statusCode:Int)
    func retryResponse(numberOfrequest:Int)
}
/// HttpHelper class for http request using alamofire libs
class HttpHelper {
    /// **HttpHelparDelegate**  interface on complete request call
    var delegate: HttpHelperDelegate?
    
    var header:HTTPHeaders?
    var numberOfrequest = 0
    var maxNumberOfrequest = 3
    
    
    
    public  func Get(url:String,parameters:Parameters=[:],Tag:Int , headers:HTTPHeaders){
        
        
        request(url: url, method: .get, parameters: parameters, tag: Tag,header: headers)
    }
    
    public  func GetWithoutHeader(url:String,parameters:Parameters=[:],Tag:Int ){
        
        request(url: url, method: .get, parameters: parameters, tag: Tag,header: nil)
    }
    
    public func requestWith(endUrl: String, imageData: [UIImage], parameters: [String : Any], tag: Int){
        
        let headers:
        HTTPHeaders = [
            "Content-type": "multipart/form-data"
        ]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            for (key, value) in parameters {
                multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
            }
            
            for image in imageData{
                if  let imageData = image.jpegData(compressionQuality: 0.5){
                multipartFormData.append(imageData, withName: "images", fileName:"image.png", mimeType: "image/png")
                }
            }
            
        }, usingThreshold: UInt64.init(), to: endUrl, method: .post, headers: headers) { (result) in
            switch result{
            case .success(let upload, _, _):
                upload.responseJSON { response in
                    if let JSON = response.result.value {
                      
                        self.delegate?.receivedResponse(dictResponse: JSON,Tag: tag)
                    }
                    print("Succesfully uploaded")
                    if let err = response.error{
//                        onError?(err)
                        return
                    }
//                    onCompletion?(nil)
                }
            case .failure(let error):
                print("Error in upload: \(error.localizedDescription)")
//                onError?(error)
            }
        }
    }

    
    
   
    public func Post(url:String,parameters:Parameters=[:],Tag:Int, headers:HTTPHeaders ){
        request(url: url, method: .post, parameters: parameters, tag: Tag,header: headers)
    }
    
    public func Postwithoutheader(url:String,parameters:Parameters=[:],Tag:Int ){
        request(url: url, method: .post, parameters: parameters, tag: Tag,header: nil)
    }
    public func PostWithBody(url:String,parameters:Parameters=[:],Tag:Int, hasAuthorized:Bool=false){
        requestWithBody(url: url, method: .post, parameters: parameters, tag: Tag,header: hasAuthorized ? header : nil)
    }

    
   
    public func Patch(url:String,parameters:Parameters=[:],Tag:Int, hasAuthorized:Bool=false){
        
        
        request(url: url, method: .patch, parameters: parameters, tag: Tag,header: hasAuthorized ? header : nil)
    }
    
    
    
    
    public func requestWithBody (url:String,method:HTTPMethod,parameters:Parameters=[:],tag:Int,header:HTTPHeaders?) {
        
        print(url)
        Alamofire.request(url , method: method, parameters: parameters, encoding: JSONEncoding.default,headers: header).responseJSON { (response) in
            debugPrint(response)
            if response.response!.statusCode == statusCode.OK  || response.response!.statusCode == statusCode.CREATED
                || response.response!.statusCode == statusCode.NO_CONTENT || response.response!.statusCode == statusCode.ACCEPTED {
                if let JSON = response.result.value {
                    //                        logger(.value, message: JSON)
                    self.delegate?.receivedResponse(dictResponse: JSON,Tag: tag)
                }
            }else if response.response!.statusCode == statusCode.BAD_GATEWAY || response.response!.statusCode == statusCode.SERVICE_UNAVAILABLE{
                let when = DispatchTime.now() + Double(0.1 * Double(self.numberOfrequest))
                DispatchQueue.main.asyncAfter(deadline: when) {
                    // Your code with delay
                    self.delegate?.retryResponse(numberOfrequest: self.numberOfrequest)
                    self.numberOfrequest  = self.numberOfrequest +  1
                }
            }else{
                self.delegate?.receivedErrorWithStatusCode(statusCode: response.response!.statusCode)
            }
        }

    }
    
    
    
    
    private func request(url:String,method:HTTPMethod,parameters:Parameters=[:],tag:Int,header:HTTPHeaders?){
//        logger(.value, message: url)
//        logger(.value, message: parameters
        
        Alamofire.request(url, method: method,parameters: parameters,headers:header)
            .responseJSON { (response) in
                print(response)
                if response.response == nil {
                    self.delegate?.receivedErrorWithStatusCode(statusCode: statusCode.NOT_FOUND)
                    return
                }
                if response.response!.statusCode == statusCode.OK  || response.response!.statusCode == statusCode.CREATED
                    || response.response!.statusCode == statusCode.NO_CONTENT || response.response!.statusCode == statusCode.ACCEPTED{
                    if let JSON = response.result.value {
//                        logger(.value, message: JSON)
                        self.delegate?.receivedResponse(dictResponse: JSON,Tag: tag)
                    }
                }else if response.response!.statusCode == statusCode.BAD_GATEWAY || response.response!.statusCode == statusCode.SERVICE_UNAVAILABLE{
                    let when = DispatchTime.now() + Double(0.1 * Double(self.numberOfrequest))
                    DispatchQueue.main.asyncAfter(deadline: when) {
                        // Your code with delay
                        self.delegate?.retryResponse(numberOfrequest: self.numberOfrequest)
                        self.numberOfrequest  = self.numberOfrequest +  1
                    }
                }else{
                    self.delegate?.receivedErrorWithStatusCode(statusCode: response.response!.statusCode)
                }
        }
    }
}

