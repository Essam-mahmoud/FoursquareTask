//
//  placeInfoCell.swift
//  foursquareTask
//
//  Created by apple on 10/30/19.
//  Copyright © 2019 apple. All rights reserved.
//

import UIKit

class placeInfoCell: UITableViewCell {

    @IBOutlet weak var nameLBL: UILabel!
    @IBOutlet weak var addressLBL: UILabel!
    @IBOutlet weak var placeImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
