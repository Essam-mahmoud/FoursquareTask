//
//  placeInfoCell.swift
//  foursquareTask
//
//  Created by apple on 10/30/19.
//  Copyright © 2019 apple. All rights reserved.
//

import UIKit
import SwiftyJSON
import Kingfisher

class placeInfoCell: UITableViewCell {
    
    @IBOutlet weak var nameLBL: UILabel!
    @IBOutlet weak var addressLBL: UILabel!
    @IBOutlet weak var placeImageView: UIImageView!
    
    var http = HttpHelper()
    override func awakeFromNib() {
        super.awakeFromNib()
        http.delegate = self
        // Initialization code
    }
    
    func setup(placeObj: placeModel){
        nameLBL.text = placeObj.name
        addressLBL.text = placeObj.address
        let id = placeObj.Id
        APIConstants.ID = id
        http.GetWithoutHeader(url: APIConstants.getVenuePhotos, parameters: [:], Tag: 1)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}


extension placeInfoCell: HttpHelperDelegate{
    func receivedResponse(dictResponse: Any, Tag: Int) {
        let json = JSON(dictResponse)
        if Tag == 1{
            let response = json["response"]
            let photos = response["photos"]
            let items = photos["items"].arrayValue
            for item in items{
                let source = item["source"]
                let prefix = source["prefix"].stringValue
                let suffix = source["suffix"].stringValue
                let StringURL = prefix + "/200x200/" + suffix
                let url = URL(string: StringURL)
                placeImageView.kf.setImage(with: url)
            }
        }
    }
    
    func receivedErrorWithStatusCode(statusCode: Int) {
       // Loader.showError(message: "Error: Please Check internet connection")
    }
    
    func retryResponse(numberOfrequest: Int) {
        
    }
    
    
}
