//
//  placeModel.swift
//  foursquareTask
//
//  Created by apple on 10/30/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation

class placeModel: NSObject{
    var Id: String
    var name: String
    var address: String
    var distance: Int

    init(Id: String,name: String,address: String,distance: Int) {
        self.Id = Id
        self.name = name
        self.address = address
        self.distance = distance
  
    }
}
