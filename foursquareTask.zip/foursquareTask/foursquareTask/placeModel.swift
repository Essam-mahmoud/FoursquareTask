//
//  placeModel.swift
//  foursquareTask
//
//  Created by apple on 10/30/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation

class placeModel: NSObject{
    var name: String
    var address: String

    init(name: String,address: String) {
        self.name = name
        self.address = address
  
    }
}
